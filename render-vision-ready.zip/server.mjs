import http from 'node:http';
import { createHash, timingSafeEqual } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const MODELS = new Set(['gemini-3.5-flash-lite', 'gemini-flash-latest', 'gemini-2.5-flash-lite']);
const MAX_BODY = 19 * 1024 * 1024;
const MAX_REPLY = 1024 * 1024;
const TOKEN = /^[A-Za-z0-9_+/=-]{32,256}$/;
const KEY = /^[A-Za-z0-9._-]{20,1024}$/;
const hash = value => createHash('sha256').update(value).digest();
class Failure extends Error { constructor(status, code) { super(code); this.status = status; this.code = code; } }

async function bounded(stream, limit, status = 413) {
  const chunks = []; let bytes = 0;
  for await (const chunk of stream) {
    bytes += chunk.length;
    if (bytes > limit) throw new Failure(status, 'relay_size');
    chunks.push(Buffer.from(chunk));
  }
  return Buffer.concat(chunks).toString('utf8');
}

function validate(body) {
  const fail = () => { throw new Failure(400, 'relay_payload'); };
  if (!body || !MODELS.has(body.model) || Object.keys(body).some(k => !['model', 'payload'].includes(k))) fail();
  const p = body.payload;
  if (!p || Object.keys(p).some(k => !['contents', 'generationConfig'].includes(k))) fail();
  if (!Array.isArray(p.contents) || p.contents.length !== 1 || p.contents[0]?.role !== 'user') fail();
  const parts = p.contents[0].parts;
  if (!Array.isArray(parts) || !parts.length || parts.length > 4) fail();
  let images = 0, texts = 0;
  for (const part of parts) {
    if (!part || Object.keys(part).length !== 1) fail();
    if (typeof part.text === 'string' && part.text.length > 0 && part.text.length <= 40000) texts++;
    else if (part.inlineData && ['image/jpeg', 'image/png', 'image/webp'].includes(part.inlineData.mimeType)
      && typeof part.inlineData.data === 'string' && /^[A-Za-z0-9+/]+={0,2}$/.test(part.inlineData.data)
      && Object.keys(part.inlineData).every(k => ['mimeType', 'data'].includes(k))) images++;
    else fail();
  }
  if (texts !== 1 || images > 3) fail();
  const g = p.generationConfig;
  if (!g || Object.keys(g).some(k => !['maxOutputTokens', 'thinkingConfig', 'responseMimeType', 'responseJsonSchema'].includes(k))
    || !Number.isInteger(g.maxOutputTokens) || g.maxOutputTokens < 1 || g.maxOutputTokens > 4096) fail();
  const thinking = g.thinkingConfig;
  if (!thinking || (body.model === 'gemini-2.5-flash-lite'
    ? Object.keys(thinking).length !== 1 || thinking.thinkingBudget !== 0
    : Object.keys(thinking).length !== 1 || thinking.thinkingLevel !== (body.model === 'gemini-3.5-flash-lite' ? 'MINIMAL' : 'LOW'))) fail();
  if (images && (g.responseMimeType !== 'application/json' || !g.responseJsonSchema)) fail();
  return { model: body.model, payload: p };
}

function safeProviderError(status, body) {
  const message = typeof body?.error?.message === 'string' ? body.error.message.toLowerCase() : '';
  const region = message.includes('user location is not supported') || message.includes('unsupported country');
  return { error: { code: region ? 'unsupported_country' : 'provider_error', message: region ? 'User location is not supported.' : 'Provider rejected the request.', upstream_status: status } };
}

export function createRelay({ token, fetchImpl = fetch, now = Date.now, upstreamTimeoutMs = 35000 } = {}) {
  if (typeof token !== 'string' || !TOKEN.test(token)) throw new Error('Set a random RELAY_TOKEN (at least 32 characters).');
  const expected = hash('Bearer ' + token);
  let active = 0, minute = Math.floor(now() / 60000), attempts = 0;
  const server = http.createServer(async (req, res) => {
    const send = (status, body) => {
      if (!res.destroyed) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(body)); }
    };
    if (req.method === 'GET' && req.url === '/healthz') {
      if (['https://4diagnostic.ru', 'https://www.4diagnostic.ru'].includes(req.headers.origin)) { res.setHeader('Access-Control-Allow-Origin', req.headers.origin); res.setHeader('Vary', 'Origin'); }
      send(200, { ok: true, service: 'fd-parts-vision', version: 1 }); return;
    }
    if (req.method !== 'POST' || req.url !== '/v1/gemini') { send(404, { error: { code: 'relay_route' } }); return; }
    const auth = req.headers.authorization;
    if (typeof auth !== 'string' || auth.length > 300 || !timingSafeEqual(hash(auth), expected)) { send(401, { error: { code: 'relay_auth' } }); return; }
    const key = req.headers['x-goog-api-key'];
    if (typeof key !== 'string' || !KEY.test(key) || key.startsWith('sk-') || key.startsWith('rk_live_')) { send(400, { error: { code: 'relay_key' } }); return; }
    if ((req.headers['content-type'] || '').split(';')[0].trim() !== 'application/json') { send(415, { error: { code: 'relay_content_type' } }); return; }
    if (Number(req.headers['content-length']) > MAX_BODY) { send(413, { error: { code: 'relay_size' } }); return; }
    const current = Math.floor(now() / 60000);
    if (current !== minute) { minute = current; attempts = 0; }
    if (active >= 2 || attempts >= 10) { send(429, { error: { code: 'relay_busy' } }); return; }
    active++;
    let controller, timeout;
    try {
      let body;
      try { body = JSON.parse(await bounded(req, MAX_BODY)); } catch (e) { if (e instanceof Failure) throw e; throw new Failure(400, 'relay_json'); }
      const { model, payload } = validate(body);
      attempts++;
      controller = new AbortController(); timeout = setTimeout(() => controller.abort(), upstreamTimeoutMs);
      // No configurable destination, redirects, retries, tools, disk writes or request logging.
      const upstream = await fetchImpl('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-goog-api-key': key },
        body: JSON.stringify(payload), redirect: 'error', signal: controller.signal
      });
      let value;
      try { value = JSON.parse(await bounded(upstream.body, MAX_REPLY, 502)); } catch (e) { if (e instanceof Failure) throw e; throw new Failure(502, 'relay_reply'); }
      if (upstream.status !== 200) { send(upstream.status >= 400 && upstream.status <= 599 ? upstream.status : 502, safeProviderError(upstream.status, value)); return; }
      if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Failure(502, 'relay_reply');
      send(200, { candidates: value.candidates, promptFeedback: value.promptFeedback });
    } catch (e) {
      send(e instanceof Failure ? e.status : 502, { error: { code: e instanceof Failure ? e.code : controller?.signal.aborted ? 'relay_timeout' : 'relay_network' } });
    } finally { clearTimeout(timeout); active--; }
  });
  server.requestTimeout = 30000;
  server.headersTimeout = 10000;
  server.keepAliveTimeout = 5000;
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const server = createRelay({ token: process.env.RELAY_TOKEN });
  server.listen(Number(process.env.PORT || 10000), '0.0.0.0', () => console.log('fd-parts-vision started'));
  process.on('SIGTERM', () => server.close());
}
