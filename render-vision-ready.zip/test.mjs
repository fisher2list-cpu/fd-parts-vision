import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRelay } from './server.mjs';

const token = 'TEST_RELAY_' + 'a'.repeat(40), key = 'AQ.TEST_' + 'b'.repeat(40);
const body = { model: 'gemini-3.5-flash-lite', payload: { contents: [{ role: 'user', parts: [{ text: 'Reply with OK.' }] }], generationConfig: { maxOutputTokens: 1024, thinkingConfig: { thinkingLevel: 'MINIMAL' } } } };
const response = { candidates: [{ finishReason: 'STOP', content: { parts: [{ text: 'OK' }] } }] };
async function withServer(fetchImpl, run, extra = {}) {
  const server = createRelay({ token, fetchImpl, ...extra });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = 'http://127.0.0.1:' + server.address().port;
  try {
    await run(async (value = body, changes = {}) => {
      const r = await fetch(base + (changes.path || '/v1/gemini'), {
        method: changes.method || 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token, 'X-goog-api-key': key, ...changes.headers },
        body: changes.method === 'GET' ? undefined : changes.raw ?? JSON.stringify(value)
      });
      return { status: r.status, headers: r.headers, data: await r.json() };
    });
  } finally { await new Promise(resolve => server.close(resolve)); }
}

test('closed startup and unauthorized requests never contact Google', async () => {
  assert.throws(() => createRelay({ token: '' }));
  let calls = 0;
  await withServer(async () => { calls++; throw new Error('must not call'); }, async request => {
    for (const Authorization of ['', 'Bearer wrong', 'Bearer ' + token + '\n']) {
      if (Authorization.includes('\n')) continue; // Browser/Node header validation already rejects CR/LF.
      assert.equal((await request(body, { headers: { Authorization } })).status, 401);
    }
    assert.equal((await request(body, { headers: { 'X-goog-api-key': 'sk-' + 'a'.repeat(40) } })).status, 400);
    assert.equal((await request(body, { path: '/other' })).status, 404);
    const health = await request(null, { method: 'GET', path: '/healthz', headers: { Authorization: '', Origin: 'https://4diagnostic.ru' } });
    assert.equal(health.status, 200); assert.equal(health.data.service, 'fd-parts-vision');
    assert.equal(health.headers.get('access-control-allow-origin'), 'https://4diagnostic.ru');
    assert.equal(calls, 0); assert(!JSON.stringify(health.data).includes(token));
  });
});

test('valid request has fixed Google destination, correct credentials and one call', async () => {
  let calls = 0;
  await withServer(async (url, options) => {
    calls++;
    assert.equal(url, 'https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent');
    assert.equal(options.redirect, 'error'); assert.equal(options.headers['X-goog-api-key'], key);
    assert(!JSON.stringify(options).includes(token)); assert.deepEqual(JSON.parse(options.body), body.payload);
    return Response.json({ ...response, privateUnknownField: key });
  }, async request => {
    const r = await request(); assert.equal(r.status, 200); assert.deepEqual(r.data, response); assert.equal(calls, 1);
    assert(!JSON.stringify(r.data).includes(key));
  });
});

test('invalid model, arbitrary destination, remote images, tools and excessive token budget denied', async () => {
  let calls = 0;
  await withServer(async () => { calls++; }, async request => {
    const cases = [
      { ...body, model: '../secret' }, { ...body, url: 'https://other.test' },
      { ...body, payload: { ...body.payload, tools: [{ googleSearch: {} }] } },
      { ...body, payload: { ...body.payload, generationConfig: { ...body.payload.generationConfig, maxOutputTokens: 5000 } } },
      { ...body, payload: { ...body.payload, contents: [{ role: 'user', parts: [{ text: 'hi' }, { fileData: { fileUri: 'https://other.test/private' } }] }] } }
    ];
    for (const value of cases) assert.equal((await request(value)).status, 400);
    assert.equal((await request(body, { raw: '{bad' })).status, 400);
    assert.equal((await request(body, { headers: { 'Content-Type': 'text/plain' } })).status, 415);
    assert.equal(calls, 0);
  });
});

test('three inline photos and schema are forwarded without credentials in the payload', async () => {
  const photo = structuredClone(body);
  for (let i = 0; i < 3; i++) photo.payload.contents[0].parts.push({ inlineData: { mimeType: 'image/jpeg', data: Buffer.from('TEST_IMAGE').toString('base64') } });
  photo.payload.generationConfig.responseMimeType = 'application/json';
  photo.payload.generationConfig.responseJsonSchema = { type: 'object', properties: { title: { type: 'string' } }, required: ['title'] };
  await withServer(async (url, options) => { assert.deepEqual(JSON.parse(options.body), photo.payload); return Response.json(response); }, async request => {
    assert.equal((await request(photo)).status, 200);
    const four = structuredClone(photo); four.payload.contents[0].parts.push(four.payload.contents[0].parts[1]); assert.equal((await request(four)).status, 400);
  });
});

test('provider errors hide raw messages, preserve region/quota and never retry', async () => {
  for (const status of [400, 401, 403, 404, 429, 503]) {
    let calls = 0;
    await withServer(async () => { calls++; return Response.json({ error: { message: 'SECRET ' + key + ' ' + token + (status === 400 ? ' User location is not supported.' : '') } }, { status }); }, async request => {
      const r = await request(); assert.equal(r.status, status); assert.equal(calls, 1);
      const raw = JSON.stringify(r.data); assert(!raw.includes(key)); assert(!raw.includes(token));
      assert.equal(r.data.error.code, status === 400 ? 'unsupported_country' : 'provider_error');
    });
  }
});

test('network and oversized upstream replies fail safely without automatic retry', async () => {
  await withServer(async () => { throw new Error('SECRET ' + token); }, async request => {
    const r = await request(); assert.equal(r.status, 502); assert.equal(r.data.error.code, 'relay_network'); assert(!JSON.stringify(r).includes(token));
  });
  await withServer(async () => new Response('x'.repeat(1024 * 1024 + 1)), async request => {
    const r = await request(); assert.equal(r.status, 502); assert.equal(r.data.error.code, 'relay_size');
  });
  await withServer(async (url, options) => new Promise((resolve, reject) => options.signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true })), async request => {
    const r = await request(); assert.equal(r.status, 502); assert.equal(r.data.error.code, 'relay_timeout');
  }, { upstreamTimeoutMs: 10 });
});

test('per-minute authenticated rate limit bounds upstream requests', async () => {
  let calls = 0;
  await withServer(async () => { calls++; return Response.json(response); }, async request => {
    for (let i = 0; i < 10; i++) assert.equal((await request()).status, 200);
    const r = await request(); assert.equal(r.status, 429); assert.equal(r.data.error.code, 'relay_busy'); assert.equal(calls, 10);
  }, { now: () => 1000 });
});
